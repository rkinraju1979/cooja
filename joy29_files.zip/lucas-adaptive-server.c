/*
 * Contiki-NG RPL-UDP Lucas-Based Adaptive Sampling Server (RPL Root Sink)
 * Target: Tmote Sky / TelosB (MSP430 / CC2420)
 * IJ-ICT 2026 Reference Implementation: Kanaka Raju Rajana & Shanmuk Srinivas Amiripalli
 */

#include "contiki.h"
#include "net/routing/routing.h"
#include "net/netstack.h"
#include "net/ipv6/simple-udp.h"
#include "sys/log.h"

#define LOG_MODULE "Lucas-Server"
#define LOG_LEVEL LOG_LEVEL_NONE

#define UDP_CLIENT_PORT 8765
#define UDP_SERVER_PORT 5678

static struct simple_udp_connection udp_conn;

PROCESS(lucas_server_process, "Lucas-Based Adaptive Sampling Server Process");
AUTOSTART_PROCESSES(&lucas_server_process);

static void udp_rx_callback(struct simple_udp_connection *c,
                            const uip_ipaddr_t *sender_addr,
                            uint16_t sender_port,
                            const uip_ipaddr_t *receiver_addr,
                            uint16_t receiver_port,
                            const uint8_t *data,
                            uint16_t datalen)
{
  LOG_INFO("Received LASS Packet from ");
  LOG_INFO_6ADDR(sender_addr);
  LOG_INFO_(" : '%.*s'\n", datalen, (char *)data);
}

PROCESS_THREAD(lucas_server_process, ev, data)
{
  PROCESS_BEGIN();

  /* Initialize RPL DODAG Root */
  NETSTACK_ROUTING.root_start();

  /* Register Simple UDP listener matching client port configuration */
  simple_udp_register(&udp_conn, UDP_SERVER_PORT, NULL,
                      UDP_CLIENT_PORT, udp_rx_callback);

  LOG_INFO("Lucas RPL-UDP DODAG Root Server Started on Port %d\n", UDP_SERVER_PORT);

  PROCESS_END();
}

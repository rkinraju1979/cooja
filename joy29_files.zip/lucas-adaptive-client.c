/*
 * Contiki-NG RPL-UDP Universal Hierarchical Clustering Client
 * Target: Tmote Sky / TelosB (MSP430 / CC2420)
 * IJ-ICT 2026 Reference Implementation: Kanaka Raju Rajana & Shanmuk Srinivas Amiripalli
 *
 * Universal Hierarchical Protocol Principles for ALL 4 Deployments (Low, Medium, High & Lucas):
 * 1. Dedicated RPL Root Sink Node (Node 1) emits DIO messages building the IPv6 RPL DODAG tree.
 * 2. Cluster Members (CMs / Leaf Motes) sample sensor data dynamically and transmit UDP packets
 *    DIRECTLY to their local Cluster Head (CH) link-local IPv6 address.
 * 3. Cluster Heads (CHs / Hub Motes) receive CM packets on UDP_CH_PORT (8766), aggregate payloads,
 *    and relay them over the CH-to-Sink RPL Backbone tree directly to RPL Root Sink Node 1.
 */

#include "contiki.h"
#include "net/routing/routing.h"
#include "net/netstack.h"
#include "net/ipv6/simple-udp.h"
#include "sys/log.h"
#include "random.h"
#include "net/linkaddr.h"
#include <string.h>

#define LOG_MODULE "Lucas-Client"
#define LOG_LEVEL LOG_LEVEL_NONE

#define UDP_CLIENT_PORT 8765
#define UDP_SERVER_PORT 5678
#define UDP_CH_PORT     8766

static struct simple_udp_connection udp_conn_ch;
static struct simple_udp_connection udp_conn_sink;

/* Sampling Mode Definitions */
typedef enum {
  SAMPLING_LOW = 0,     /* Fixed 10s interval (20 Clusters x 5 Nodes) */
  SAMPLING_MEDIUM = 1,  /* Fixed 50s interval (5 Clusters x 20 Nodes) */
  SAMPLING_HIGH = 2,    /* Fixed 80s interval (2 Clusters x 50 Nodes) */
  SAMPLING_RANDOM = 3,  /* Random interval */
  SAMPLING_LUCAS = 4    /* Lucas Sequence Adaptive Interval (LASS: 9 Clusters) */
} sampling_mode_t;

static sampling_mode_t current_mode = SAMPLING_LUCAS;

/* Lucas Sequence for Adaptive Intervals (seconds): L_0=2, L_1=1, L_2=3, L_3=4, L_4=7, L_5=11, L_6=18, L_7=29, L_8=47, L_9=76, L_10=123, L_11=199 */
static const clock_time_t lucas_seq[] = {2, 1, 3, 4, 7, 11, 18, 29, 47, 76, 123, 199};
static uint8_t lucas_idx = 0;

/* Designated Cluster Head (CH) Node IDs for Lucas Adaptive Deployment */
static const uint8_t ch_node_ids_lucas[] = {2, 4, 5, 8, 12, 19, 30, 48, 77};
#define NUM_CH_LUCAS (sizeof(ch_node_ids_lucas) / sizeof(ch_node_ids_lucas[0]))

/* Universal Role Assignment across ALL 4 Deployments */
static bool is_cluster_head_node(uint8_t id) {
  if(id < 2) return false;
  if(current_mode == SAMPLING_LOW) {
    return (id <= 97 && ((id - 2) % 5 == 0));
  } else if(current_mode == SAMPLING_MEDIUM) {
    return (id == 2 || id == 22 || id == 42 || id == 62 || id == 82);
  } else if(current_mode == SAMPLING_HIGH) {
    return (id == 2 || id == 52);
  } else { /* SAMPLING_LUCAS */
    for(uint8_t i = 0; i < NUM_CH_LUCAS; i++) {
      if(ch_node_ids_lucas[i] == id) return true;
    }
    return false;
  }
}

/* Universal Cluster Head Mapping across ALL 4 Deployments */
static uint8_t get_my_cluster_head_id(uint8_t my_id) {
  if(my_id < 2) return 2;
  if(current_mode == SAMPLING_LOW) {
    uint8_t cluster_idx = (my_id - 2) / 5;
    return 2 + cluster_idx * 5;
  } else if(current_mode == SAMPLING_MEDIUM) {
    if(my_id <= 21) return 2;
    if(my_id <= 41) return 22;
    if(my_id <= 61) return 42;
    if(my_id <= 81) return 62;
    return 82;
  } else if(current_mode == SAMPLING_HIGH) {
    if(my_id <= 51) return 2;
    return 52;
  } else { /* SAMPLING_LUCAS */
    if(my_id <= 3)   return 2;
    if(my_id <= 4)   return 4;
    if(my_id <= 7)   return 5;
    if(my_id <= 11)  return 8;
    if(my_id <= 18)  return 12;
    if(my_id <= 29)  return 19;
    if(my_id <= 47)  return 30;
    if(my_id <= 76)  return 48;
    return 77;
  }
}

/* Construct Contiki-NG Sky Mote IPv6 Link-Local Address from Node ID */
static void get_mote_ipaddr(uip_ipaddr_t *ipaddr, uint8_t node_id) {
  uip_ip6addr(ipaddr, 0xfe80, 0, 0, 0, 0x0212, 0x7400, 0, node_id);
}

PROCESS(lucas_client_process, "Universal RPL-UDP Hierarchical Clustering Client");
AUTOSTART_PROCESSES(&lucas_client_process);

static clock_time_t get_next_sampling_interval(void) {
  clock_time_t interval_sec = 10;
  if(current_mode == SAMPLING_LOW) {
    interval_sec = 10;
  } else if(current_mode == SAMPLING_MEDIUM) {
    interval_sec = 50;
  } else if(current_mode == SAMPLING_HIGH) {
    interval_sec = 80;
  } else if(current_mode == SAMPLING_RANDOM) {
    interval_sec = 10 + (random_rand() % 70);
  } else if(current_mode == SAMPLING_LUCAS) {
    interval_sec = lucas_seq[lucas_idx];
    lucas_idx = (lucas_idx + 1) % (sizeof(lucas_seq) / sizeof(lucas_seq[0]));
  }
  return interval_sec * CLOCK_SECOND;
}

/* CH Callback: CH receives intra-cluster CM payload & relays via RPL CH-to-Sink backbone to Sink Node 1 */
static void ch_rx_callback(struct simple_udp_connection *c,
                           const uip_ipaddr_t *sender_addr,
                           uint16_t sender_port,
                           const uip_ipaddr_t *receiver_addr,
                           uint16_t receiver_port,
                           const uint8_t *data,
                           uint16_t datalen)
{
  uip_ipaddr_t sink_ipaddr;
  uint8_t my_id = linkaddr_node_addr.u8[1];
  
  LOG_INFO("CH %u Received CM Payload\n", my_id);

  /* CH-to-Sink Direct Relay over RPL Tree to Root Sink Node 1 */
  if(NETSTACK_ROUTING.node_is_reachable() && NETSTACK_ROUTING.get_root_ipaddr(&sink_ipaddr)) {
    static char relay_buf[32] = "CH_RELAY_PAYLOAD";
    LOG_INFO("CH %u Relaying to Sink\n", my_id);
    simple_udp_sendto(&udp_conn_sink, relay_buf, 16, &sink_ipaddr);
  }
}

PROCESS_THREAD(lucas_client_process, ev, data)
{
  static struct etimer periodic_timer;
  static bool has_joined = false;
  static uip_ipaddr_t sink_ipaddr;
  static uint8_t my_id = 0;
  static bool my_role_is_ch = false;

  PROCESS_BEGIN();

  my_id = linkaddr_node_addr.u8[1];
  my_role_is_ch = is_cluster_head_node(my_id);

  if(my_role_is_ch) {
    LOG_INFO("Mote %u Initialized CH\n", my_id);
    simple_udp_register(&udp_conn_ch, UDP_CH_PORT, NULL,
                        UDP_CLIENT_PORT, ch_rx_callback);
  } else {
    LOG_INFO("Mote %u Initialized CM -> CH %u\n", my_id, get_my_cluster_head_id(my_id));
  }

  simple_udp_register(&udp_conn_sink, UDP_CLIENT_PORT, NULL,
                      UDP_SERVER_PORT, NULL);

  etimer_set(&periodic_timer, 30 * CLOCK_SECOND + (random_rand() % (10 * CLOCK_SECOND)));

  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic_timer));

    if(NETSTACK_ROUTING.node_is_reachable() && NETSTACK_ROUTING.get_root_ipaddr(&sink_ipaddr)) {
      if(!has_joined) {
        has_joined = true;
        LOG_INFO("Joined RPL Tree\n");
      }

      if(my_role_is_ch) {
        static char ch_buf[24] = "CH_BEACON_DATA";
        LOG_INFO("CH %u Sending to Sink\n", my_id);
        simple_udp_sendto(&udp_conn_sink, ch_buf, 14, &sink_ipaddr);
      } else {
        uip_ipaddr_t ch_ipaddr;
        uint8_t target_ch = get_my_cluster_head_id(my_id);
        get_mote_ipaddr(&ch_ipaddr, target_ch);

        static char cm_buf[24] = "CM_SENSOR_DATA";
        LOG_INFO("CM %u Sending to CH %u\n", my_id, target_ch);
        simple_udp_sendto(&udp_conn_ch, cm_buf, 14, &ch_ipaddr);
      }
    }

    etimer_set(&periodic_timer, get_next_sampling_interval());
  }

  PROCESS_END();
}
